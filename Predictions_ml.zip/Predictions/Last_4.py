from keras.layers import Embedding
from keras.models import Sequential
from keras.datasets import imdb
import keras as K
import numpy as np

max_words = 20000

(train_x, train_y), (test_x, test_y) = imdb.load_data(num_words=max_words)

max_review_length = 80
train_x = K.preprocessing.sequence.pad_sequences(train_x, truncating='pre', padding='pre', maxlen=max_review_length)
test_x = K.preprocessing.sequence.pad_sequences(test_x, truncating='pre', padding='pre', maxlen=max_review_length)

model = Sequential()
embedding_length = 5
max_words = 1000
max_sentence_length = 10
model.add(Embedding(max_words, embedding_length, input_length=max_sentence_length))
# the model will take as input an integer matrix of size (batch, input_length).
# the largest integer (i.e. word index) in the input should be
# no larger than max_words-1 (vocabulary size).
# now model.output_shape == (None, max_review_length, embedding_length), where None is the batch dimension.


input_array = input_array = np.random.randint(max_words, size=(2, max_sentence_length)) #train_x[0]
print(input_array, np.shape(input_array))

model.compile('rmsprop', 'mse')
output_array = model.predict(input_array)
#assert output_array.shape == (32, 10, 64)
print(output_array, np.shape(output_array))



"""# One hot representation"""

from keras.preprocessing.text import one_hot

#define documents
docs = ['glass of orange juice',
        'bottle of mango juice',
        'glass of mango shake',
        'drink bottle of banana shake',
        'I want a glass of cold water',
        'The king and the queen',
        'man and woman']

vocab_size = 10000

encoded_docs = [one_hot(d, vocab_size) for d in docs]
print(encoded_docs)

"""# Word Embeddings"""

from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Embedding, LSTM

import numpy as np

embedding_length = 5
max_doc_len = 10

encoded_docs = pad_sequences(encoded_docs, truncating='post', padding='post', maxlen=max_doc_len)

print(encoded_docs)

model = Sequential()

model.add(Embedding(vocab_size, embedding_length, input_length=max_doc_len))
model.add(LSTM(units=64))

model.compile('rmsprop', 'mse')

model.summary()

output = model.predict(encoded_docs)
print(output.shape)
print(output)

"""##Putting it together
#Sentiment Analysis in Keras

Import libraries and dataset
"""

import keras
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding
from keras.layers import LSTM
from keras.datasets import imdb

max_words = 20000

print('Loading data...')
(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_words)
print(len(x_train), 'train sequences')
print(len(x_test), 'test sequences')

"""Pre-processing"""

# cut texts after this number of words (among top max_features most common words)
max_review_length = 80

x_train = sequence.pad_sequences(x_train, truncating='pre', padding='pre', maxlen=max_review_length)
x_test = sequence.pad_sequences(x_test, truncating='pre', padding='pre', maxlen=max_review_length)

print('x_train shape:', x_train.shape)
print('x_test shape:', x_test.shape)

"""Build the model"""

print('Build model...')
embedding_length = 64
model = Sequential()
model.add(Embedding(input_dim=max_words, output_dim=embedding_length, input_length=max_review_length))
model.add(LSTM(units=64, input_shape=(max_review_length, embedding_length), return_sequences=False, unroll=True))
model.add(Dense(1, activation='sigmoid'))

# try using different optimizers and different optimizer configs
model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

"""Visualize the model"""

#Visualize
model.summary()

from keras.utils import plot_model
plot_model(model, show_shapes=True, to_file='sent_analysis_model.png')

"""Train the model"""

print('Training...')
batch_size = 32

model.fit(x_train, y_train,
          batch_size = batch_size,
          epochs=10,
          validation_data = (x_test, y_test))

"""Evaluate the model"""

score, acc = model.evaluate(x_test, y_test, batch_size=batch_size)
print(f'Test score = {score}')
print(f'Test accuracy = {acc}')

"""Making predictions with model"""

#review = "The movie was a great waste of time."
review = "It was a great movie."
print(f'New review = {review}')

d = imdb.get_word_index()
words = review.split()
review = []

for word in words:
  if word not in d:
    review.append(2)
  else:
    review.append(d[word] + 3)
  
print(f"review = {review}")

review = sequence.pad_sequences([review], truncating='pre', padding='pre', maxlen=80)

prediction = model.predict(review)
print(f'Prediction (0 = Negative, 1 = positive) = {prediction}')

