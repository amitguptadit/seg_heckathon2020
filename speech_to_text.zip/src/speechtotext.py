import speech_recognition as sr  

# get audio from the device  microphone                                                                       
recogniser = sr.Recognizer()                                                                                   
with sr.Microphone() as source:                                                                       
    print("Now Speak :")                                                                                   
    audio = recogniser.listen(source,timeout=3)   

try:
    print("Recognising....")
    print("You said  " + recogniser.recognize_google(audio))
except sr.UnknownValueError:
    print("I didn't hear anything :( ")
except sr.RequestError as ex:
    print("Not able to get the result; {0}".format(ex))